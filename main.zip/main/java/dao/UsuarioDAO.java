package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.Usuario;
import model.ConexionBD;

public class UsuarioDAO {

    // Método para insertar un usuario
    public boolean insertarUsuario(Usuario usuario) {
        String INSERT_SQL = "INSERT INTO usuario (email, username, password, name) VALUES (?, ?, ?, ?)";
        try (Connection connection = ConexionBD.getConnection();
             PreparedStatement statement = connection.prepareStatement(INSERT_SQL)) {
            // Establecer los valores de los parámetros
            statement.setString(1, usuario.getEmail());
            statement.setString(2, usuario.getUsername());
            statement.setString(3, usuario.getPassword());
            statement.setString(4, usuario.getName());
            // Ejecutar la consulta de inserción
            int filasInsertadas = statement.executeUpdate();

            // Verificar si se insertaron filas exitosamente
            if (filasInsertadas > 0) {
                System.out.println("Usuario insertado correctamente a la base de datos.");
                return true;
            } else {
                System.out.println("No se pudo insertar el usuario a la base de datos.");
                return false;   
            }
        } catch (SQLException e) {
            System.err.println("Error al insertar el usuario a la base de datos: " + e.getMessage());
            return false;
        }
    }

    // Método para obtener un usuario por su ID
    public Usuario obtenerUsuario(int id) {
        String SELECT_SQL = "SELECT * FROM usuario WHERE id = ?";
        try (Connection connection = ConexionBD.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_SQL)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    String email = resultSet.getString("email");
                    String username = resultSet.getString("username");
                    String password = resultSet.getString("password");
                    String name = resultSet.getString("name");
                    return new Usuario(email, username, password, name);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener el usuario de la base de datos: " + e.getMessage());
        }
        return null;
    }

    // Método para eliminar un usuario por su ID
    public boolean eliminarUsuario(int id) {
        String DELETE_SQL = "DELETE FROM usuario WHERE id = ?";
        try (Connection connection = ConexionBD.getConnection();
             PreparedStatement statement = connection.prepareStatement(DELETE_SQL)) {
            statement.setInt(1, id);
            int filasEliminadas = statement.executeUpdate();
            if (filasEliminadas > 0) {
                System.out.println("Usuario eliminado correctamente de la base de datos.");
                return true;
            } else {
                System.out.println("No se pudo eliminar el usuario de la base de datos.");
                return false;
            }
        } catch (SQLException e) {
            System.err.println("Error al eliminar el usuario de la base de datos: " + e.getMessage());
            return false;
        }
    }

    // Método para actualizar un usuario
    public boolean actualizarUsuario(Usuario usuario) {
        String UPDATE_SQL = "UPDATE usuario SET email = ?, username = ?, password = ?, name = ? WHERE id = ?";
        try (Connection connection = ConexionBD.getConnection();
             PreparedStatement statement = connection.prepareStatement(UPDATE_SQL)) {
            // Establecer los valores de los parámetros
            statement.setString(1, usuario.getEmail());
            statement.setString(2, usuario.getUsername());
            statement.setString(3, usuario.getPassword());
            statement.setString(4, usuario.getName());
            // Ejecutar la consulta de actualización
            int filasActualizadas = statement.executeUpdate();
            if (filasActualizadas > 0) {
                System.out.println("Usuario actualizado correctamente en la base de datos.");
                return true;
            } else {
                System.out.println("No se pudo actualizar el usuario en la base de datos.");
                return false;
            }
        } catch (SQLException e) {
            System.err.println("Error al actualizar el usuario en la base de datos: " + e.getMessage());
            return false;
        }
    }
    public Usuario autenticarUsuario(String username, String password) {
        String SELECT_SQL = "SELECT * FROM usuario WHERE username = ? AND password = ?";
        try (Connection connection = ConexionBD.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_SQL)) {
            statement.setString(1, username);
            statement.setString(2, password);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    String email = resultSet.getString("email");
                    String name = resultSet.getString("name");
                    return new Usuario(email, username, password, name);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al autenticar el usuario: " + e.getMessage());
        }
        return null;
    }

}
