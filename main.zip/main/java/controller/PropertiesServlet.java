package controller;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.json.JSONArray;
import org.json.JSONObject;

@WebServlet("/propiedades")
public class PropertiesServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Aquí puedes recuperar las propiedades de tu base de datos o de donde las tengas almacenadas
        JSONArray propiedades = new JSONArray();
        propiedades.put(new JSONObject().put("id", 1).put("nombre", "Casa 1"));
        propiedades.put(new JSONObject().put("id", 2).put("nombre", "Casa 2"));
        // Más propiedades...

        // Configurar la respuesta como JSON
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        // Enviar la lista de propiedades como JSON
        PrintWriter out = response.getWriter();
        out.print(propiedades.toString());
        out.flush();
    }
}

